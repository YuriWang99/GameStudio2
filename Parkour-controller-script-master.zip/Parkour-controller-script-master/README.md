Scripts from my (mostly completed) Unity project attempting to recreate certain Titanfall movement mechanics,
here is the link to folder with working (I guess?) builds: 
https://drive.google.com/open?id=16SmKSvGpYe7tI7bmxdFz8_qxUBLfTBmA

I would like to give special thanks to MOM-2236, BlackHawk133457 and other memebers of the Titanfall Remnant Fleet community who helped me gain great knowledge about Titanfall mechanics, playtested my builds and gave me valuable feedback.
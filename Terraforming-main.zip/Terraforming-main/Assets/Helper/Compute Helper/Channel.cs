﻿namespace ComputeShaderUtility
{

	public enum Channel
	{
		Red,
		Green,
		Blue,
		Alpha,
		Zero
	}
}